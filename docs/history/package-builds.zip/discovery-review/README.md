# Mathematical discovery skill review

Current source: root `SKILL.md`, `references/`, `scripts/research.py` and
`scripts/math_research/`. The built portable package is `solve-this-discovery/`;
older builds remain historical revisions.

- `check.txt`: SkillWren static check and evidence audit, zero errors/warnings.
- `workflow.txt`: deterministic explanation of the actual research control flow.
- `coverage.txt` / `coverage.json`: 0 host-enforced, 16 recordable, 3 instructed
  obligations. Recordable is a capability of ledger auditing, not proof that a
  host ledger was activated. No runtime SkillWren policy is configured.
- `source-hashes.json`: exact source bytes included in the 28-file package.
- `build.txt`: actual SkillWren build result; `manifest.json` in the output binds
  the package bytes. Pure package validation is not mathematical proof.

The three instructed gates concern request presence, current authorization and
resource fit, and adequacy of the adopted literature audit/research program.
The runtime independently preserves the fixed Hadamard objective, requires an
adopted audit/program, checks journal integrity and proof cycles, and executes a
Lean proof gate for the exact original statement. It is not host isolation.
The quality of an audit and interpretation of English claims remain research
judgments; stored hashes cannot establish those judgments correct.

See [the requirement inventory](../research/hadamard/REQUIREMENTS.md),
[research program](../research/hadamard/PROGRAM.md) and
[results](../research/hadamard/RESULTS.md). No human approval of the exact package
bytes has been recorded, and no general mathematical novelty is claimed.

```powershell
py -3 -B scripts/build_discovery.py --check-only
py -3 -B -m pytest tests -q
```

Build with `--out <new-directory>` to retain prior artifacts. If the intended
meaning is acceptable, the user may record approval themselves with SkillWren's
`approve solve-this-discovery/SKILL.md`; the agent never runs it for them.
