# Solve This conversion review

This reviews the earlier PoC-oriented conversion. The current mathematical
discovery architecture is built with `scripts/build_discovery.py` and reviewed
in `discovery-review/`; the immutable-objective research program is under
`research/hadamard/`. Historical build and measurement artifacts below are retained.

Built with the updated local SkillWren 0.13.3 checkout and the tested field patches
now applied at `Z:\SkillWren`; exact toolchain hashes are in `toolchain.json`.
The user confirmed the preservation scope before the draft was written.
No human approval of the resulting bytes has been recorded.

- `../solve-this-tuned/`: tuned package; `manifest.json` binds its 13 source files.
- `../solve-this/`: initial 12-file build, retained as the field-test baseline.
- `../solve-this-draft/`: editable draft; `.skillwren/budget.json` retains checker history.
- `requirements.md` and `requirements.json`: each substantive original line quoted
  with its landing anchors; the ten original references remain byte-for-byte,
  and the field-tested research-backlog reference is added.
- `inventory-check.json`: SkillWren's source coverage, landing and reverse-trace check.
- `check.txt`: static check and evidence audit.
- `workflow.txt`: deterministic explanation generated from the logic.
- `coverage.txt` and `coverage.json`: generated coverage classification.
- `build.txt`: build result.
- `mutation-fixtures/`: deliberately invalid copies used to test gate bypass detection;
  these are review fixtures, not installable skills.

Validation completed: all 8 repository tests passed, including the 5 conversion
tests. The checker rejected all four deliberate bypasses (authorization,
target-evidence, safe-repetition and verified completion). Package hashes,
reference preservation and local links passed; skill-creator validation passed.
The final check-only reproduction and requirement inventory also passed.

## Interpretation and limits

The static check has zero errors and one documented W15 warning. The order rule
requiring plan generation before the target-evidence gate relies on model judgment;
the plan is held in working context rather than requiring an artifact write for
every action. This preserves lightweight execution without pretending that
predeclaration is independently recorded.

Coverage reports **0 enforced, 10 recorded, 9 instructed, 0 unverifiable**. Its
“recorded” category describes steps capable of supporting a cooperative ledger
audit; no ledger or trusted host policy is installed or activated here. Nothing
outside the model stops or records execution of the instructed requirements:
inspection-effect assessment, reconciliation availability, budget, decision value,
prediction/recovery completeness, and predeclaring the plan. Evidence-linked
gates still require interpretation of natural-language claims. No runtime
enforcement, semantic equivalence or behavioral improvement is established.

The original workflow explanation incorrectly said “Effects: none declared; the
workflow changes nothing” despite an execution step. The field investigation
fixed SkillWren's explainer; the current raw report lists command effects and
does not give that assurance. `exec planned action` explicitly permits
authorized mutations, tests, writes, polling and recovery and is never marked
readonly. The raw generated report is retained without editing.

All reads must have understood authorized effects; commands and state-changing
operations go through the action gates. Missing authority or a new necessary
decision after effects stops the affected branch with partial state and the
required input reported. It does not imply rollback or require reapproval of
already authorized work. A later response can resume the investigation.

The requirement inventory checks source-line coverage and literal landing
anchors. Some source paragraphs contain multiple clauses; their complete text
is retained rather than silently dropped. The mapping is model-authored and
does not prove each paraphrase preserves every nuance. Supporting references
are copied exactly. The root prose skill has one new research-backlog route;
the installer continues to install the prose skill.

## Reproduce

From the repository root:

```powershell
py -3 -B scripts/build_skillwren.py --skillwren-root Z:\SkillWren --check-only
py -3 -B -m unittest discover -s tests -p test_skillwren.py -v
```

Build to a new destination with `--out <new-folder>` without `--check-only`.
The builder refuses to overwrite an existing destination. Set `SKILLWREN_ROOT`
for the tests when the checkout is not this repository's sibling.

Read `workflow.txt` alongside the step meanings in the built `SKILL.md`.
If the converted meaning is acceptable, the user may record approval themselves:

```powershell
py -3 -B Z:\SkillWren\skills\skillwren\scripts\skillwren.py approve solve-this-tuned\SKILL.md
```

That optional approval records intent for those bytes. It does not install the
skill, grant capabilities, or activate runtime enforcement. The build and
mutation tests do not run paid model evaluations.
